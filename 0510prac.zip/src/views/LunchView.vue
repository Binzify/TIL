<template>
  <div class="lunch">
    <h1>Lunch 페이지</h1>
    <button @click="pickOne">점심 메뉴 추천</button>
    <p>{{ selectedMenu }}</p>
    <hr>
    <input type="text" v-model="lottoNum">
    <button @click="pickLotto">추천해줘!</button>
    <hr>
    <button @click="moveToHome">Home으로 이동</button>
  </div>
</template>

<script>
import _ from 'lodash'
export default {
  name: 'LunchView',
  data: function(){
    return {
      menus : ['국밥', '도넛', '샌드위치'],
      selectedMenu : null,
      lottoNums: null,
    }
  },
  methods: {
    pickOne : function() {
      this.selectedMenu = _.sample(this.menus)
    },
    moveToHome: function(){
      this.$router.push({ name: 'Home' })
    },
    pickLotto : function() {
      this.$router.push({ name: 'Lotto', params: { lottoNum:this.lottoNum }})
    },
  }
}
</script>

<style>

</style>