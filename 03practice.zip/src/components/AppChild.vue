<template>
  <div>
    <h1>AppChild</h1>
    <input type="text" @input="onChildInputChange" :value="childData">
    <p>appData: {{ appData }}</p>
    <p>parentData: {{ parentData }}</p>
    <p>childData: {{ childData }}</p>
  </div>
</template>

<script>
export default {
  name: 'AppChild',
  props : {
    appData:String,
    parentData:String,
    childData:String,
  },
  methods: {
    onChildInputChange: function (event) {
      this.$emit('child-input-change', event.target.value)
    }
  }
}
</script>

<style>

</style>