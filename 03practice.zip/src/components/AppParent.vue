<template>
  <div>
    <h1>AppParent</h1>
    <input type="text" :value="parentData" @input="onParentInputChange">
    <p>appData: {{ appData }}</p>
    <p>childData: {{ childData }}</p>
    <app-child 
      :app-data="appData" 
      :parent-data="parentData"
      :child-data="childData"
      @child-input-change="onChildInputChange"></app-child>
  </div>
</template>

<script>
import AppChild from './AppChild.vue'

export default {
  name: 'AppParent',
  components: {
    AppChild,
  },
  props : {
    appData:String,
    parentData:String,
    childData:String,
  },
  methods : {
    onParentInputChange: function (event) {
      this.$emit('parent-input-change', event.target.value)
    },
    onChildInputChange: function (childInputData) {
      this.$emit('child-input-change', childInputData)
    }
  } 
} 
</script>

<style>

</style>