<template>
  <div id="app">
    <h1>App</h1>
    <input type="text" v-model="appData">
    <p>parentData: {{ parentData }}</p>
    <p>childData: {{ childData }}</p>
    <app-parent 
      :app-data="appData"
      :parent-data = "parentData"
      :child-data = "childData"
      @parent-input-change="parentGetData"
      @child-input-change="childGetData"></app-parent>
  </div>
</template>

<script>
import AppParent from './components/AppParent.vue'

export default {
  name: 'App',
  components: {
    AppParent,
  },
  data: function () {
    return {
      appData: null,
      parentData: null,
      childData: null,
    }
  },
  methods : {
    parentGetData: function (parentInputData) {
      this.parentData = parentInputData
    },
    childGetData: function (childInputData) {
      this.childData = childInputData
    },
  } 
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
